# Backend Data — Lot 4

## Ce que fait ce lot

Ce module fournit les **lieux à deviner** au reste du jeu : leur image, leurs
vraies coordonnées, et toute la logique de sélection + calcul de score.
Il ne s'occupe ni de l'affichage, ni du déroulement des manches (ça, c'est le
lot 3 "Backend Game").

## Structure des fichiers

```
backend-data/
├── locations.json     ← les données brutes (id, image, lat/lon, pays)
├── data_service.py    ← toute la logique (pas de FastAPI dedans)
├── main.py             ← les routes HTTP qui exposent data_service
└── README.md
```

**Pourquoi séparer `data_service.py` de `main.py` ?**
Parce que `data_service.py` ne dépend d'aucun framework web : on peut le
tester seul avec `python3 data_service.py`, et surtout la personne du lot 3
peut directement `import data_service` dans son propre code Python sans
passer par une requête HTTP, si c'est plus pratique pour son architecture.

## Le point le plus important : la sécurité anti-triche

**Le frontend ne reçoit JAMAIS les coordonnées avant que le joueur ait validé
sa réponse.**

- `GET /api/locations/random` renvoie seulement `{id, image_url}`
- Le joueur place son point sur la carte, le frontend envoie `{location_id,
  guess_lat, guess_lon}` à `POST /api/locations/guess`
- C'est LE SERVEUR qui calcule la distance et le score, et qui ne révèle la
  vraie position qu'à ce moment-là, dans la réponse

Si on faisait le calcul de distance côté React, il faudrait envoyer lat/lon
au frontend dès le début de la manche — n'importe qui pourrait les lire dans
l'onglet Réseau du navigateur et tricher. **C'est le point à mettre en avant
à l'oral** : ça montre qu'on a pensé à la sécurité, pas juste à faire
fonctionner le jeu.

## Les fonctions clés (à expliquer à l'oral)

### `get_random_locations(count, region)`
Tire des lieux au hasard **sans doublon** grâce à `random.sample()` (plutôt
qu'une boucle avec `random.choice()`, qui pourrait retirer deux fois le même
lieu). Le paramètre `region` permet de filtrer par pays — c'est la base du
futur mode "France / Monde".

### `calculate_distance_km(lat1, lon1, lat2, lon2)`
Calcule la distance à vol d'oiseau avec la **formule de Haversine**.
À expliquer simplement : la Terre est une sphère, donc on ne peut pas juste
faire du Pythagore sur des degrés de latitude/longitude (un degré de
longitude ne vaut pas la même distance à l'équateur qu'au pôle Nord). La
formule de Haversine calcule l'angle entre deux points vus du centre de la
Terre, puis le convertit en distance avec le rayon terrestre (6371 km).

### `score_from_distance(distance_km, max_distance_km)`
Convertit la distance en points (0 à 5000) avec une **décroissance
exponentielle** plutôt que linéaire : une erreur de 10 km est presque sans
conséquence, mais l'écart entre "proche" et "loin" se creuse vite. C'est le
même principe que le vrai GeoGuessr.

## Comment lancer et tester

```bash
pip install fastapi uvicorn
uvicorn main:app --reload
```

Puis ouvrir `http://127.0.0.1:8000/docs` : FastAPI génère automatiquement une
interface pour tester les endpoints sans écrire de code (pratique pour la
démo à l'oral).

Tester juste la logique sans serveur :
```bash
python3 data_service.py
```

## Les 2 endpoints à connaître

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/api/locations/random?count=5&region=France` | Début de partie : tire N lieux, renvoie image_url uniquement |
| POST | `/api/locations/guess` | Fin de manche : reçoit le clic du joueur, renvoie distance + score + vraie position |

## Limites actuelles / pistes d'amélioration si le temps le permet

- **Seulement 5 lieux** pour l'instant (Tour Eiffel, Statue de la Liberté,
  Big Ben, Colisée, Sydney Opera House) — largement assez pour une démo,
  mais à étoffer avant le rendu final pour éviter que le jeu se répète.
- **Comment ajouter un lieu** : chercher son nom sur
  `commons.wikimedia.org`, ouvrir une photo, relever son nom de fichier
  exact (ex: `File:Big Ben 1.jpg`), puis construire l'URL sous la forme
  `https://commons.wikimedia.org/wiki/Special:FilePath/<nom_du_fichier>`
  (avec les espaces remplacés par `%20`). Cette URL redirige toujours vers
  l'image en pleine résolution, aucune clé API n'est nécessaire.
- Le stockage reste un simple fichier JSON (cohérent avec la contrainte
  "pas de BDD" du projet) — si la liste grossit beaucoup, on pourrait migrer
  vers SQLite, mais ce n'est pas nécessaire pour ce projet.
- `difficulty` est présent dans les données mais pas encore utilisé — prêt
  si on veut ajouter un mode "facile / difficile" plus tard.
