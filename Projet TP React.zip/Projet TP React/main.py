"""
main.py
-------
Point d'entrée FastAPI du lot 4. Ce fichier est volontairement mince :
toute la logique vit dans data_service.py, ici on ne fait que la brancher
sur des routes HTTP.

Lancer le serveur : uvicorn main:app --reload
Documentation interactive générée automatiquement : http://127.0.0.1:8000/docs
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import data_service

app = FastAPI(title="GeoGuessr-like — Data API")

# CORS : autorise le frontend React (qui tourne sur un autre port, ex: 5173)
# à appeler cette API depuis le navigateur. Sans ça, le navigateur bloque
# la requête par sécurité (politique "same-origin").
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # à restreindre à l'URL du frontend en production
    allow_methods=["*"],
    allow_headers=["*"],
)


class LocationPublic(BaseModel):
    """
    Ce que le frontend reçoit AVANT que le joueur ait répondu.
    Pas de lat/lon ici : c'est le point de sécurité important, expliqué
    dans le README. Si on renvoyait les coordonnées à ce stade, un joueur
    pourrait les lire dans l'onglet "Réseau" du navigateur et tricher.
    """
    id: int
    image_url: str


class GuessRequest(BaseModel):
    """Ce que le frontend envoie quand le joueur valide son clic sur la carte."""
    location_id: int
    guess_lat: float
    guess_lon: float


class GuessResult(BaseModel):
    """Ce que l'API renvoie après validation : la vérité, enfin dévoilée."""
    distance_km: float
    score: int
    actual_lat: float
    actual_lon: float
    name: str


@app.get("/api/locations/random", response_model=list[LocationPublic])
def random_locations(
    count: int = Query(5, ge=1, le=20, description="Nombre de manches"),
    region: str | None = Query(None, description="Ex: 'France' pour le mode France"),
):
    """
    Endpoint appelé par le lot 3 (backend logique de jeu) au début d'une partie.
    Renvoie uniquement id + image_url : jamais les coordonnées à ce stade.
    """
    locations = data_service.get_random_locations(count=count, region=region)
    return [{"id": loc["id"], "image_url": loc["image_url"]} for loc in locations]


@app.post("/api/locations/guess", response_model=GuessResult)
def validate_guess(guess: GuessRequest):
    """
    Endpoint appelé quand le joueur valide sa réponse pour une manche.
    C'est ICI, côté serveur, que la distance et le score sont calculés —
    jamais côté frontend — puisque le frontend n'a pas accès à la vraie position.
    """
    location = data_service.get_location_by_id(guess.location_id)
    if location is None:
        raise HTTPException(status_code=404, detail="Lieu introuvable")

    distance = data_service.calculate_distance_km(
        guess.guess_lat, guess.guess_lon, location["lat"], location["lon"]
    )
    score = data_service.score_from_distance(distance)

    return GuessResult(
        distance_km=round(distance, 1),
        score=score,
        actual_lat=location["lat"],
        actual_lon=location["lon"],
        name=location["name"],
    )


@app.get("/")
def health_check():
    """Simple route pour vérifier que le serveur tourne."""
    return {"status": "ok", "service": "backend-data"}
