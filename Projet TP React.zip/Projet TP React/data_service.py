"""
data_service.py
----------------
Ce module contient TOUTE la logique liée aux données de jeu (lot 4) :
  - charger les lieux depuis locations.json
  - en tirer une sélection aléatoire (sans doublon, avec filtre région)
  - calculer la distance réelle entre un point et un lieu (formule de Haversine)

C'est ce module que la personne en charge du backend "Logique de jeu" (lot 3)
importe pour valider les réponses des joueurs. Il ne dépend d'aucun framework
web : on peut le tester tout seul, sans lancer de serveur.
"""

import json
import math
import random
from pathlib import Path
from typing import Optional

# Chemin du fichier de données, à côté de ce script
DATA_FILE = Path(__file__).parent / "locations.json"


def load_locations() -> list[dict]:
    """
    Charge tous les lieux depuis locations.json et les renvoie sous forme
    de liste de dictionnaires.

    On recharge le fichier à chaque appel plutôt que de le garder en mémoire
    une fois pour toutes : ça reste rapide (le fichier est petit) et ça permet
    de modifier locations.json sans redémarrer le serveur.
    """
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def get_random_locations(count: int = 5, region: Optional[str] = None) -> list[dict]:
    """
    Tire `count` lieux au hasard, sans doublon.

    - region : si fourni (ex: "France"), on ne pioche que dans les lieux
      de ce pays. Sert pour un futur mode "France only" vs "Monde".
    - Si `count` dépasse le nombre de lieux disponibles, on renvoie tout
      ce qu'on a (pas d'erreur) : utile tant que la base de données est petite.

    On utilise random.sample() plutôt qu'une boucle avec random.choice() :
    sample() garantit qu'un même lieu n'est jamais tiré deux fois dans la
    même partie, sans avoir à coder de vérification à la main.
    """
    locations = load_locations()

    if region:
        locations = [loc for loc in locations if loc["country"].lower() == region.lower()]

    count = min(count, len(locations))
    return random.sample(locations, count)


def get_location_by_id(location_id: int) -> Optional[dict]:
    """
    Retrouve un lieu précis à partir de son id.
    Renvoie None si l'id n'existe pas (le lot 3 doit gérer ce cas,
    par exemple avec une erreur 404).
    """
    locations = load_locations()
    for loc in locations:
        if loc["id"] == location_id:
            return loc
    return None


def calculate_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Distance à vol d'oiseau entre deux points GPS, en kilomètres.

    Pourquoi pas une simple distance euclidienne (Pythagore) sur lat/lon ?
    Parce que la Terre est une sphère : un degré de longitude ne représente
    pas la même distance à l'équateur qu'près des pôles. Il faut donc la
    formule de Haversine, qui tient compte de la courbure terrestre.

    Étapes :
      1. Convertir les degrés en radians (les fonctions trigonométriques
         de Python travaillent en radians).
      2. Calculer la différence de latitude et de longitude entre les 2 points.
      3. Appliquer la formule de Haversine pour obtenir l'angle central
         entre les deux points, vu du centre de la Terre.
      4. Multiplier cet angle par le rayon de la Terre pour obtenir une distance.
    """
    R = 6371  # rayon moyen de la Terre en km

    lat1_rad, lon1_rad = math.radians(lat1), math.radians(lon1)
    lat2_rad, lon2_rad = math.radians(lat2), math.radians(lon2)

    delta_lat = lat2_rad - lat1_rad
    delta_lon = lon2_rad - lon1_rad

    a = (
        math.sin(delta_lat / 2) ** 2
        + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def score_from_distance(distance_km: float, max_distance_km: float = 2000) -> int:
    """
    Convertit une distance en points, sur un barème 0 - 5000 (comme GeoGuessr).

    Principe : plus la distance est petite, plus le score est élevé.
    On utilise une décroissance exponentielle plutôt que linéaire, pour que :
      - une petite erreur (quelques km) soit à peine pénalisée
      - l'écart entre "assez proche" et "très loin" soit fortement marqué
    Au-delà de `max_distance_km`, le score tombe à 0.

    Cette fonction reste dans le lot 4 (données) car le "barème de scoring"
    est une règle qui dépend directement de nos données géographiques ;
    le lot 3 n'a qu'à l'appeler avec la distance calculée.
    """
    if distance_km >= max_distance_km:
        return 0
    score = 5000 * math.exp(-distance_km / (max_distance_km / 4))
    return round(score)


if __name__ == "__main__":
    # Petit auto-test pour vérifier que tout fonctionne sans lancer FastAPI.
    # Lancer avec : python data_service.py
    print("Tous les lieux :", [l["name"] for l in load_locations()])

    tirage = get_random_locations(3)
    print("\nTirage aléatoire de 3 lieux :", [l["name"] for l in tirage])

    paris = get_location_by_id(1)
    print(f"\nLieu #1 : {paris['name']} ({paris['lat']}, {paris['lon']})")

    # Un joueur place son marker à Londres alors que la vraie réponse est Paris
    d = calculate_distance_km(48.8584, 2.2945, 51.5074, -0.1278)
    print(f"\nDistance Paris -> Londres : {d:.1f} km")
    print(f"Score correspondant : {score_from_distance(d)} points")
